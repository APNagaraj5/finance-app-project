# Cloud-Based Personal Finance Management System
This repository contains a complete scaffold to build, run, and deploy the Finance App:
- backend/        : Lambda handler and local Flask server
- mobile/         : React Native app skeleton
- infrastructure/ : SQL schema and Terraform starter
- ci/             : Jenkinsfile for CI/CD
- docs/           : This document and original specification (p4.docx)

## Next steps (recommended)
1. Provision AWS resources (RDS, S3, IAM) and update environment variables.
2. Deploy Lambda using AWS Console, Serverless Framework, or Terraform.
3. Build the mobile app and connect to deployed API (update base URLs).
4. Secure the API using AWS Cognito or a token-based auth system.
5. Add tests and expand CI pipeline to run tests and deploy automatically.

## Included files
See the top-level README.md for quick instructions in each component.
