import json
import os
import boto3
from botocore.exceptions import ClientError

# Example Lambda handler for adding a transaction to RDS via Data API
rds_data = boto3.client('rds-data')  # requires proper IAM role and ARNs in env

DB_RESOURCE_ARN = os.environ.get('DB_RESOURCE_ARN', 'your-db-cluster-arn')
DB_SECRET_ARN = os.environ.get('DB_SECRET_ARN', 'your-db-secret-arn')
DB_NAME = os.environ.get('DB_NAME', 'finance_db')

def lambda_handler(event, context):
    # Expect a JSON body with: user_id, amount, description, category
    try:
        body = event.get('body')
        if isinstance(body, str):
            data = json.loads(body)
        else:
            data = body or {}
        user_id = data['user_id']
        amount = float(data['amount'])
        description = data.get('description','')
        category = data.get('category','uncategorized')

        sql = """INSERT INTO transactions (user_id, amount, description, category)
        VALUES (:user_id, :amount, :description, :category);"""

        params = [
            {{'name':'user_id','value':{'stringValue': user_id}}},
            {{'name':'amount','value':{'doubleValue': amount}}},
            {{'name':'description','value':{'stringValue': description}}},
            {{'name':'category','value':{'stringValue': category}}}
        ]

        resp = rds_data.execute_statement(
            resourceArn=DB_RESOURCE_ARN,
            secretArn=DB_SECRET_ARN,
            database=DB_NAME,
            sql=sql,
            parameters=params
        )

        return {{
            'statusCode': 200,
            'body': json.dumps({{'message':'Transaction added'}}),
            'headers': {{ 'Content-Type': 'application/json' }}
        }}
    except KeyError as e:
        return {{ 'statusCode': 400, 'body': json.dumps({{'error':f'Missing field: {e}'}}) }}
    except ClientError as e:
        return {{ 'statusCode': 500, 'body': json.dumps({{'error': str(e)}}) }}
    except Exception as e:
        return {{ 'statusCode': 500, 'body': json.dumps({{'error': str(e)}}) }}
