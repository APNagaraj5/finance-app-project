# Backend
Contains:
- lambda_function.py : AWS Lambda handler (Python) that writes transactions to RDS via Data API.
- local_server.py : Simple Flask server for local development (mimics endpoints).
- requirements.txt : Python dependencies.

Quick start (local):
1. Create a virtualenv and install dependencies:
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
2. Run local server:
   python local_server.py
