# Simple Flask app to run locally and mimic the Lambda endpoint for development/testing.
from flask import Flask, request, jsonify
import json
app = Flask(__name__)

@app.route('/transactions', methods=['POST'])
def add_transaction():
    data = request.get_json()
    # For local dev, we'll just echo back (replace with DB logic if desired)
    return jsonify({'received': data}), 200

@app.route('/transactions', methods=['GET'])
def list_transactions():
    # In real app, this would query RDS. Here we return sample data for UI dev.
    sample = [
        {{'transaction_id':1, 'user_id':'user1','amount':12.5,'description':'Coffee','category':'food'}},
        {{'transaction_id':2, 'user_id':'user1','amount':45.0,'description':'Groceries','category':'groceries'}}
    ]
    return jsonify(sample), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
