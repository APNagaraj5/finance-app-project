# Finance App - Project Scaffold
This archive was generated automatically and contains a full scaffold to start development.

Folders:
- backend: Lambda handler + local Flask dev server
- mobile: React Native skeleton
- infrastructure: SQL schema + Terraform skeleton
- ci: Jenkins pipeline
- docs: Project overview + original spec (p4_original.docx)

Download the zip and follow the README files in each folder.
