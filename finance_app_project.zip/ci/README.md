# CI/CD
- Jenkinsfile : Example pipeline with build/test/deploy stages.
Customize stages to use AWS CLI, Serverless Framework, or Terraform.
