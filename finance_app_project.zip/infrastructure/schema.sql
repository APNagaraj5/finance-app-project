-- PostgreSQL schema for the Finance App
CREATE TABLE IF NOT EXISTS transactions (
  transaction_id SERIAL PRIMARY KEY,
  user_id VARCHAR(255),
  amount DECIMAL,
  description TEXT,
  category VARCHAR(50),
  transaction_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS budgets (
  budget_id SERIAL PRIMARY KEY,
  user_id VARCHAR(255),
  category VARCHAR(50),
  limit_amount DECIMAL,
  current_spending DECIMAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS savings_goals (
  goal_id SERIAL PRIMARY KEY,
  user_id VARCHAR(255),
  goal_name VARCHAR(255),
  target_amount DECIMAL,
  current_savings DECIMAL DEFAULT 0
);
