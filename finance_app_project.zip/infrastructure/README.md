# Infrastructure
- schema.sql : SQL schema for the app
- terraform_main.tf : Starter Terraform config (skeleton). Customize as needed.

Tips:
- For RDS in production, use a multi-AZ PostgreSQL instance or Aurora Serverless v2.
- Use AWS Secrets Manager for DB credentials and give the Lambda role access to RDS Data API.
