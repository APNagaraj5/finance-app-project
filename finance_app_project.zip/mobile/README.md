# Mobile (React Native)
Minimal app skeleton with:
- App.js
- screens/TransactionsScreen.js
- screens/SpendingChart.js

Quick start:
1. Install dependencies: npm install
2. Start Metro: npm start
3. Run on emulator: npm run android
Note: For local backend on Android emulator, use http://10.0.2.2:5000
