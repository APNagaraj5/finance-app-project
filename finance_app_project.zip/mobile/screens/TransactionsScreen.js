import React, { useState, useEffect } from 'react';
import { View, Text, FlatList } from 'react-native';
import axios from 'axios';

const TransactionsScreen = () => {
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    // Replace with your backend endpoint when available
    axios.get('http://10.0.2.2:5000/transactions')
      .then(res => setTransactions(res.data))
      .catch(err => {
        console.warn('Could not fetch transactions (using sample data).', err.message);
        setTransactions([
          { transaction_id:1, user_id:'user1', amount:12.5, description:'Coffee', category:'food' },
          { transaction_id:2, user_id:'user1', amount:45.0, description:'Groceries', category:'groceries' }
        ]);
      });
  }, []);

  return (
    <View style={{padding:16}}>
      <Text style={{fontSize:20, fontWeight:'bold', marginBottom:8}}>Transactions</Text>
      <FlatList
        data={transactions}
        keyExtractor={item => item.transaction_id.toString()}
        renderItem={({item}) => (
          <View style={{paddingVertical:8}}>
            <Text>{item.description} — ₹{item.amount}</Text>
            <Text style={{color:'#666'}}>{item.category}</Text>
          </View>
        )}
      />
    </View>
  );
};

export default TransactionsScreen;
