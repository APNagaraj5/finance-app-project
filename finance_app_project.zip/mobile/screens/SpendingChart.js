import React from 'react';
import { LineChart } from 'react-native-chart-kit';
import { Dimensions, View } from 'react-native';

const screenWidth = Dimensions.get('window').width;

const SpendingChart = ({ data }) => (
  <View>
    <LineChart
      data={{
        labels:['Mon','Tue','Wed','Thu','Fri'],
        datasets:[{ data }]
      }}
      width={screenWidth - 32}
      height={220}
      yAxisLabel="₹"
      chartConfig={{
        decimalPlaces: 2,
        color: (opacity=1) => `rgba(0,0,0,${opacity})`,
        labelColor: (opacity=1) => `rgba(0,0,0,${opacity})`
      }}
      style={{ borderRadius:8 }}
    />
  </View>
);

export default SpendingChart;
