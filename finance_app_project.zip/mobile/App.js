import React from 'react';
import { SafeAreaView, Text } from 'react-native';
import TransactionsScreen from './screens/TransactionsScreen';

const App = () => {
  return (
    <SafeAreaView style={{flex:1}}>
      <TransactionsScreen />
    </SafeAreaView>
  );
};

export default App;
